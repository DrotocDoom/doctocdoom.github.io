/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package constant;

/**
 *
 * @author nguyen
 */
public interface IQuery {

    final String QUERY_GET_ALL_USERS = "SELECT * FROM users";

    final String QUERY_GET_USER_BY_ID = "SELECT TOP 1 * FROM users WHERE user_id = ?";

    final String QUERY_GET_USER_BY_EMAIL_AND_PASSWORD = "SELECT TOP 1 * FROM users WHERE email = ? AND password = ?";

    final String QUERY_GET_USER_BY_EMAIL = "SELECT TOP 1 * FROM users WHERE email = ?";

    final String QUERY_UPDATE_USER
            = "UPDATE users SET "
            + "email = ?, "
            + "first_name = ?, "
            + "last_name = ?, "
            + "password = ?, "
            + "is_admin = ? "
            + "WHERE user_id = ?";

    final String QUERY_INSERT_USER
            = "INSERT INTO users "
            + "(email, "
            + "first_name, "
            + "last_name, "
            + "password, "
            + "is_admin) "
            + "VALUES (?, ?, ?, ?, ?)";

    final String QUERY_DELETE_USER = "DELETE FROM users WHERE user_id = ?";

    final String QUERY_GET_ALL_CUSTOMER
            = "SELECT "
            + "c.customer_id, "
            + "c.address, "
            + "c.phone_number, "
            + "u.user_id,"
            + "u.email, "
            + "u.first_name, "
            + "u.last_name, "
            + "u.password, "
            + "u.is_admin "
            + "FROM customers c "
            + "INNER JOIN users u ON c.user_id = u.user_id";

    final String QUERY_GET_CUSTOMER_BY_USER_ID
            = "SELECT "
            + "c.customer_id, "
            + "c.address, "
            + "c.phone_number, "
            + "u.user_id,"
            + "u.email, "
            + "u.first_name, "
            + "u.last_name, "
            + "u.password, "
            + "u.is_admin "
            + "FROM customers c "
            + "INNER JOIN users u ON c.user_id = u.user_id "
            + "WHERE c.user_id = ?";

    final String QUERY_UPDATE_CUSTOMER
            = "UPDATE customers "
            + "SET user_id = ?, address = ?, phone_number = ? "
            + "WHERE customer_id = ?";

    final String QUERY_INSERT_CUSTOMER
            = "INSERT INTO customers "
            + "(user_id, address, phone_number) "
            + "VALUES (?, ?, ?)";
    final String QUERY_DELETE_CUSTOMER
            = "DELETE FROM customers "
            + "WHERE customer_id = ?";

    final String QUERY_GET_ALL_CATEGORIES
            = "SELECT * FROM categories";

    final String QUERY_GET_CATEGORY_BY_ID
            = "SELECT * FROM categories WHERE category_id = ?";

    final String QUERY_INSERT_CATEGORY
            = "INSERT INTO categories "
            + "(category_name, "
            + "description, "
            + "is_active) "
            + "VALUES (?, ?, ?)";

    final String QUERY_UPDATE_CATEGORY
            = "UPDATE categories "
            + "SET category_name = ?, "
            + "description = ?, "
            + "is_active = ? "
            + "WHERE category_id = ?";

    final String QUERY_DELETE_CATEGORY
            = "DELETE FROM categories WHERE category_id = ?";

    final String QUERY_COUNT_ALL_PRODUCTS = "SELECT COUNT(*) FROM products";

    final String QUERY_GET_ALL_PRODUCTS
            = "SELECT p.*, "
            + "c.category_name, "
            + "c.is_active AS c_is_active "
            + "FROM products p "
            + "INNER JOIN categories c ON p.category_id = c.category_id";

    final String QUERY_GET_PAGINATED_PRODUCTS
            = "SELECT\n"
            + "    p.*, c.category_name, c.is_active AS c_is_active \n"
            + "FROM\n"
            + "    products p\n"
            + "INNER JOIN\n"
            + "    categories c ON p.category_id = c.category_id\n"
            + "WHERE\n"
            + "    p.is_active = 1\n"
            + // Filter for active products
            "ORDER BY\n"
            + "    p.product_id\n"
            + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    final String QUERY_GET_PAGINATED_PRODUCT_BY_NAME_LIKE
            = "SELECT\n"
            + "    p.*, c.category_name, c.is_active AS c_is_active \n"
            + "FROM\n"
            + "    products p\n"
            + "INNER JOIN\n"
            + "    categories c ON p.category_id = c.category_id\n"
            + "WHERE\n"
            + "    p.product_name LIKE ? AND p.is_active = 1\n"
            + "ORDER BY\n"
            + "    p.product_id\n"
            + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    final String QUERY_GET_PRODUCT_BY_ID
            = "SELECT TOP 1 p.*, "
            + "c.category_name, "
            + "c.is_active AS c_is_active "
            + "FROM products p "
            + "INNER JOIN categories c ON p.category_id = c.category_id "
            + "WHERE p.product_id = ?";

    final String QUERY_GET_PRODUCT_BY_NAME_LIKE
            = "SELECT TOP 1 "
            + "p.*, "
            + "c.category_name, "
            + "c.is_active AS c_is_active "
            + "FROM products p "
            + "INNER JOIN categories c ON p.category_id = c.category_id "
            + "WHERE p.product_name LIKE ?";

    final String QUERY_ALL_PRODUCTS_CATEGORY_ID = "SELECT p.*, "
            + "c.category_name, "
            + "c.is_active AS c_is_active "
            + "FROM products p "
            + "INNER JOIN categories c ON p.category_id = c.category_id "
            + "WHERE c.category_id  = ?";

    final String QUERY_INSERT_PRODUCT
            = "INSERT INTO products "
            + "(product_name, "
            + "description, "
            + "price, "
            + "stock_quantity, "
            + "category_id, "
            + "image_url, "
            + "is_active) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?)";

    final String QUERY_UPDATE_PRODUCT
            = "UPDATE products "
            + "SET product_name = ?, "
            + "description = ?, "
            + "price = ?, "
            + "stock_quantity = ?, "
            + "category_id = ?, "
            + "image_url = ?, "
            + "is_active = ? "
            + "WHERE product_id = ?";

    final String QUERY_DELETE_PRODUCT
            = "DELETE FROM products WHERE product_id = ?";

    final String QUERY_GET_ALL_ORDERS
            = "SELECT o.*, c.*, u.*, t.total_price\n"
            + "FROM orders o\n"
            + "INNER JOIN customers c ON o.customer_id = c.customer_id\n"
            + "INNER JOIN users u ON c.user_id = u.user_id\n"
            + "LEFT JOIN (\n"
            + "    SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS total_price\n"
            + "    FROM order_items oi\n"
            + "    GROUP BY oi.order_id\n"
            + ") t ON o.order_id = t.order_id\n"
            + "ORDER BY o.order_date DESC;";

    final String GET_ALL_STATUS
            = "SELECT o.status\n"
            + "FROM orders o\n"
            + "INNER JOIN customers c ON o.customer_id = c.customer_id\n"
            + "INNER JOIN users u ON c.user_id = u.user_id\n"
            + "LEFT JOIN (\n"
            + "    SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS total_price\n"
            + "    FROM order_items oi\n"
            + "    GROUP BY oi.order_id\n"
            + ") t ON o.order_id = t.order_id\n"
            + "ORDER BY o.order_date DESC";

    final String QUERY_GET_ORDER_BY_STATUS
            = "SELECT o.*, c.*, u.*, t.total_price\n"
            + "FROM orders o\n"
            + "INNER JOIN customers c ON o.customer_id = c.customer_id\n"
            + "INNER JOIN users u ON c.user_id = u.user_id\n"
            + "LEFT JOIN (\n"
            + "    SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS total_price\n"
            + "    FROM order_items oi\n"
            + "    GROUP BY oi.order_id\n"
            + ") t ON o.order_id = t.order_id\n"
            + "WHERE o.status = ? \n"
            + "ORDER BY o.order_date DESC;";

    final String QUERY_GET_ORDER_BY_STATUS_TOP1 = ""
            + "SELECT TOP 1 o.*, c.*, u.*, t.total_price\n"
            + "FROM orders o\n"
            + "INNER JOIN customers c ON o.customer_id = c.customer_id\n"
            + "INNER JOIN users u ON c.user_id = u.user_id\n"
            + "LEFT JOIN (\n"
            + "    SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS total_price\n"
            + "    FROM order_items oi\n"
            + "    GROUP BY oi.order_id\n"
            + ") t ON o.order_id = t.order_id\n"
            + "WHERE o.status = ? \n"
            + "ORDER BY o.order_date DESC;";

    final String QUERY_GET_ORDER_BY_ID
            = "SELECT o.*, c.*, u.*, t.total_price\n"
            + "FROM orders o\n"
            + "INNER JOIN customers c ON o.customer_id = c.customer_id\n"
            + "INNER JOIN users u ON c.user_id = u.user_id\n"
            + "LEFT JOIN (\n"
            + "    SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS total_price\n"
            + "    FROM order_items oi\n"
            + "    GROUP BY oi.order_id\n"
            + ") t ON o.order_id = t.order_id\n"
            + "WHERE o.order_id = ?\n"
            + "ORDER BY o.order_date DESC;";

    final String QUERY_GET_ORDER_BY_CUSTOMER_ID
            = "SELECT o.*, c.*, u.*, t.total_price\n"
            + "FROM orders o\n"
            + "INNER JOIN customers c ON o.customer_id = c.customer_id\n"
            + "INNER JOIN users u ON c.user_id = u.user_id\n"
            + "LEFT JOIN (\n"
            + "    SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS total_price\n"
            + "    FROM order_items oi\n"
            + "    GROUP BY oi.order_id\n"
            + ") t ON o.order_id = t.order_id\n"
            + "WHERE o.customer_id = ?\n"
            + "ORDER BY o.order_date DESC;";

    final String QUERY_INSERT_ORDER
            = "INSERT INTO orders (customer_id, order_date, status) "
            + "VALUES (?, ?, ?)";

    final String QUERY_UPDATE_ORDER
            = "UPDATE orders "
            + "SET customer_id = ?, order_date = ?, status = ? "
            + "WHERE order_id = ?";

    final String QUERY_DELETE_ORDER
            = "DELETE FROM orders WHERE order_id = ?";

    final String QUERY_INSERT_ORDER_ITEM
            = "INSERT INTO order_items (order_id, product_id, quantity, unit_price) "
            + "VALUES (?, ?, ?, ?)";

    final String QUERY_GET_ALL_ORDER_ITEMS
            = "SELECT "
            + "oi.order_id, "
            + "oi.quantity, "
            + "oi.unit_price, "
            + "p.product_id, "
            + "p.product_name, "
            + "p.description, "
            + "p.price, "
            + "p.stock_quantity, "
            + "p.category_id, "
            + "c.category_name, "
            + "c.is_active AS c_is_active, "
            + "p.image_url, "
            + "p.is_active "
            + "FROM order_items oi "
            + "INNER JOIN products p ON oi.product_id = p.product_id "
            + "INNER JOIN categories c ON p.category_id = c.category_id";

    final String QUERY_GET_ALL_ORDER_ITEMS_BY_ORDER_ID
            = "SELECT "
            + "oi.order_id, "
            + "oi.quantity, "
            + "oi.unit_price, "
            + "p.product_id, "
            + "p.product_name, "
            + "p.description, "
            + "p.price, "
            + "p.stock_quantity, "
            + "p.category_id, "
            + "c.category_name, "
            + "c.is_active AS c_is_active, "
            + "p.image_url, "
            + "p.is_active "
            + "FROM order_items oi "
            + "INNER JOIN products p ON oi.product_id = p.product_id "
            + "INNER JOIN categories c ON p.category_id = c.category_id "
            + "WHERE order_id = ?";

}

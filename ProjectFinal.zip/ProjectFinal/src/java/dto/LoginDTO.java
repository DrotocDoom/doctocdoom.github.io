/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 *
 * @author nguyen
 */
@Data
@AllArgsConstructor
public class LoginDTO {

    private String email;
    private String password;
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 *
 * @author nguyen
 */
@Data
@AllArgsConstructor
public class RegisterDTO {

    private String firstName;
    private String lastName;
    private String email;
    private String password;

    public User convertToUser() {
        return User.builder()
                .email(email)
                .password(password)
                .firstName(firstName)
                .lastName(lastName)
                .isAdmin(Boolean.FALSE)
                .build();
    }
}

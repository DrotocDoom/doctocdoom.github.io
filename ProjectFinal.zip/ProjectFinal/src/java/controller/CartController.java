/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.ProductDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author nguyen
 */
@WebServlet(name = "CartController", urlPatterns = {"/cart"})
public class CartController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CartController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CartController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (request.getSession().getAttribute("user") == null) {
            response.sendRedirect("login");
            return;
        }
        Map<Long, Integer> cart = (Map) request.getSession().getAttribute("cart");
        if (cart == null) {
            cart = new LinkedHashMap<>();
        }
        if (request.getParameter("add") != null) {
            Long productId = Long.parseLong(request.getParameter("id"));
            if (cart.containsKey(productId)) {
                cart.put(productId, cart.get(productId) + 1);
            } else {
                cart.put(productId, 1);
            }
        }
        if (request.getParameter("remove") != null) {
            Long productId = Long.parseLong(request.getParameter("id"));
            cart.remove(productId);
        }
        request.getSession().setAttribute("cart", cart);
        request.setAttribute("productDao", new ProductDAO());
        request.setAttribute("link", "cart.jsp");
        request.getRequestDispatcher("cart/include.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Map<Long, Integer> cart = (Map<Long, Integer>) request.getSession().getAttribute("cart");
        if (request.getParameter("update") != null) {
            if (cart == null) {
                cart = new LinkedHashMap<>();
            } else {
                String[] productIds = request.getParameterValues("productId");
                String[] quantities = request.getParameterValues("quantity");

                for (int i = 0; i < productIds.length; i++) {
                    Long productId = Long.parseLong(productIds[i]);
                    Integer newQuantity = Integer.parseInt(quantities[i]);
                    cart.put(productId, newQuantity);
                }
            }
        }
        if (request.getParameter("removeAll") != null) {
            cart = null;
        }
        request.getSession().setAttribute("cart", cart);
        response.sendRedirect("cart");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.CategoryDAO;
import dao.ProductDAO;
import entity.Category;
import entity.Product;
import entity.User;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;

/**
 *
 * @author nguyen
 */
@WebServlet(name = "ProductManagementController", urlPatterns = {"/products"})
public class ProductManagementController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProductManagementController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ProductManagementController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !user.getIsAdmin()) {
            response.sendRedirect("login");
            return;
        }
        request.setAttribute("link", "products.jsp");
        if (request.getParameter("add") != null) {
            request.setAttribute("categories", categoryDAO.findAll());
            request.setAttribute("link", "add-product.jsp");
            request.getRequestDispatcher("dashboard/include.jsp").forward(request, response);
            return;
        }

        if (request.getParameter("update") != null) {
            request.setAttribute("product", getProduct(request));
            request.setAttribute("categories", categoryDAO.findAll());
            request.setAttribute("link", "update-product.jsp");
            request.getRequestDispatcher("dashboard/include.jsp").forward(request, response);
            return;
        }

        if (request.getParameter("delete") != null) {
            deleteProduct(request);
            response.sendRedirect("products");
            return;
        }

        request.setAttribute("products", getListProduct(request));
        request.setAttribute("totalProduct", productDAO.countAll());
        request.getRequestDispatcher("dashboard/include.jsp").forward(request, response);
    }

    private Product getProduct(HttpServletRequest request) {
        Long id = Long.parseLong(request.getParameter("id"));
        return productDAO.findById(id);
    }

    private List<Product> getListProduct(HttpServletRequest request) {
        String pageString = request.getParameter("page");
        String search = request.getParameter("search");
        int page;
        try {
            page = (pageString != null) ? Integer.parseInt(pageString) : 1;
        } catch (NumberFormatException e) {
            System.err.println("Invalid page number format. Using default page 1.");
            page = 1;
        }
        request.setAttribute("page", page);
        if (search != null) {
            return productDAO.findByNameLike(page, search);
        } else {
            return productDAO.findAll(page);
        }
    }

    private void deleteProduct(HttpServletRequest request) {
        productDAO.delete(getProduct(request));
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("categories", categoryDAO.findAll());
        String add = request.getParameter("add");
        String update = request.getParameter("update");
        String error = null;
        String link = "";
        try {

            String name = request.getParameter("name");
            String description = request.getParameter("description");
            Double price = Double.parseDouble(request.getParameter("price"));
            Integer quantity = Integer.parseInt(request.getParameter("quantity"));
            Long categoryid = Long.parseLong(request.getParameter("category"));
            String image = request.getParameter("image");

            if (add != null) {
                Product product = Product.builder()
                        .name(name)
                        .description(description)
                        .price(price)
                        .stockQuantity(quantity)
                        .category(Category.builder().id(categoryid).build())
                        .imageUrl(image)
                        .isActive(Boolean.TRUE)
                        .build();
                productDAO.save(product);
                response.sendRedirect("products");
                return;
            }

            if (getProduct(request) != null && update != null) {
                Long id = Long.parseLong(request.getParameter("id"));
                Product product = Product.builder()
                        .id(id)
                        .name(name)
                        .description(description)
                        .price(price)
                        .stockQuantity(quantity)
                        .category(Category.builder().id(categoryid).build())
                        .imageUrl(image)
                        .isActive(Boolean.TRUE)
                        .build();
                productDAO.save(product);
                response.sendRedirect("products");
                return;
            }

        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
            error = "Invalid Data";
        }

        if (add != null) {
            link = "add-product.jsp";
        } else {
            link = "update-product.jsp";
        }
        request.setAttribute("error", error);
        request.setAttribute("link", link);
        request.getRequestDispatcher("dashboard/include.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

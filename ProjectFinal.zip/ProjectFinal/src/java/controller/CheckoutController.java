/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dao.CustomerDAO;
import dao.OrderDAO;
import dao.OrderItemDAO;
import dao.ProductDAO;
import entity.Customer;
import entity.Order;
import entity.OrderItem;
import entity.Product;
import entity.User;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 *
 * @author nguyen
 */
@WebServlet(name = "CheckoutController", urlPatterns = {"/checkout"})
public class CheckoutController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CheckoutController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CheckoutController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    private final OrderDAO orderDAO = new OrderDAO();
    private final OrderItemDAO orderItemDAO = new OrderItemDAO();

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        request.setAttribute("link", "history.jsp");
        if (user == null) {
            response.sendRedirect("login");
            return;
        }
        List<Order> orders;
        String idString = request.getParameter("id");
        if (idString != null) {
            Long id = Long.parseLong(idString);
            request.setAttribute("order", orderDAO.findById(id));
            request.setAttribute("link", "history-detail.jsp");
        }
        Customer customer = new CustomerDAO().findByUserId(user.getId());
        try {
            orders = orderDAO.findAllByCustomerId(customer.getId());
        } catch (Exception e) {
            orders = null;
        }
        request.setAttribute("orders", orders);
        request.getRequestDispatcher("history/include.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if (new CustomerDAO().findByUserId(user.getId()) == null) {
            response.sendRedirect("CustormerInfo?id=" + user.getId());
            return;
        }

        Order newOrder = new Order();
        newOrder.setCustomer(Customer.builder().id(user.getId()).build());
        newOrder.setStatus("Pending");
        newOrder.setOrderDate(new java.sql.Date(new Date().getTime()));
        newOrder = orderDAO.save(newOrder);

        Map<Long, Integer> cart = (Map<Long, Integer>) request.getSession().getAttribute("cart");
        for (Long productId : cart.keySet()) {
            int quantity = cart.get(productId);
            Product product = new ProductDAO().findById(productId);
            OrderItem orderItem = new OrderItem();
            orderItem.setOrderId(newOrder.getId());
            orderItem.setProduct(product);
            orderItem.setQuantity(quantity);
            orderItem.setUnitPrice(product.getPrice());
            orderItemDAO.save(orderItem);
        }
        request.getSession().setAttribute("cart", null);
        response.sendRedirect("checkout");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

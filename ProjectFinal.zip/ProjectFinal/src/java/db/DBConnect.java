/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HOME
 */
public class DBConnect {

    private final String SERVER_NAME = "localhost";
    private final String PORT_NUMBER = "1433";

    private final String DB_NAME = "ProjectFinal";
    private final String USERNAME = "sa";
    private final String PASSWORD = "123456";

    public DBConnect() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Can't load SQL Server");
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        new DBConnect().getConnection();
    }

    public Connection getConnection() {
        Connection connection = null;
        try {
            String DB_URL = "jdbc:sqlserver://" + SERVER_NAME + ":" + PORT_NUMBER + ";databaseName=" + DB_NAME;
            connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            System.out.println("Connected");
        } catch (SQLException e) {
            System.out.println("Can't connect SQL Server");
            System.out.println(e);
        }
        return connection;
    }

    public void closeResources(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) {
        try {
            if (resultSet != null && !resultSet.isClosed()) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    System.out.println("Error closing ResultSet");
                    System.out.println(e);
                }
            }

//            if (statement != null && !statement.isClosed()) {
//                try {
//                    statement.close();
//                } catch (SQLException e) {
//                    System.out.println("Error closing Statement");
//                    System.out.println(e);
//                }
//            }
            if (preparedStatement != null && !preparedStatement.isClosed()) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    System.out.println("Error closing Prepared Statement");
                    System.out.println(e);
                }
            }

            if (connection != null && !connection.isClosed()) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println("Error closing Connection");
                    System.out.println(e);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(DBConnect.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

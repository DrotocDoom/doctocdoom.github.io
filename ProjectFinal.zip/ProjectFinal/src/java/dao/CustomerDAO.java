/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import constant.IQuery;
import entity.Customer;
import entity.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyen
 */
public class CustomerDAO extends ModelDAO {

    private List<Customer> find(String query, String... args) {
        List<Customer> customers = new ArrayList<>();
        try {
            setupPreStatement(query);
            for (int i = 0; i < args.length; i++) {
                preStatement.setString(i + 1, args[i]);
            }
            resultSet = preStatement.executeQuery();
            while (resultSet.next()) {
                Customer customer = Customer.builder()
                        .id(resultSet.getLong("customer_id"))
                        .user(User.builder()
                                .id(resultSet.getLong("user_id"))
                                .firstName(resultSet.getString("first_name"))
                                .lastName(resultSet.getString("last_name"))
                                .email(resultSet.getString("email"))
                                .password(resultSet.getString("password"))
                                .isAdmin(resultSet.getBoolean("is_admin"))
                                .build()
                        )
                        .address(resultSet.getString("address"))
                        .phoneNumber(resultSet.getString("phone_number"))
                        .build();
                customers.add(customer);
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return customers;
    }

    public List<Customer> findAll() {
        String query = IQuery.QUERY_GET_ALL_CUSTOMER;
        return find(query);
    }

    public Customer findByUserId(Long id) {
        String query = IQuery.QUERY_GET_CUSTOMER_BY_USER_ID;
        List<Customer> searched = find(query, id.toString());
        return searched.isEmpty() ? null : searched.get(0);
    }

    public static void main(String[] args) {
        CustomerDAO dao = new CustomerDAO();
        Customer customer = dao.findByUserId(1L);
        System.out.println(customer);
    }

    public Customer save(Customer customer) {
        try {
            boolean insertMode = (customer.getId() == null);
            if (!insertMode) {
                setupPreStatement(IQuery.QUERY_UPDATE_CUSTOMER);
                preStatement.setLong(4, customer.getId());
            } else {
                setupPreStatement(IQuery.QUERY_INSERT_CUSTOMER);
            }
            preStatement.setLong(1, customer.getUser().getId());
            preStatement.setString(2, customer.getAddress());
            preStatement.setString(3, customer.getPhoneNumber());

            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                if (insertMode) {
                    try ( ResultSet generatedKeys = preStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            customer.setId(generatedKeys.getLong(1));
                        }
                    }
                }
                return customer;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

    public Customer delete(Customer customer) {
        try {
            setupPreStatement(IQuery.QUERY_DELETE_CUSTOMER);
            preStatement.setLong(1, customer.getId());
            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                return customer;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import constant.IQuery;
import entity.Category;
import entity.OrderItem;
import entity.Product;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyen
 */
public class OrderItemDAO extends ModelDAO {

    public static void main(String[] args) {
        new OrderItemDAO().findAll().forEach(c -> System.out.println(c));
    }

    private List<OrderItem> find(String query, String... args) {
        List<OrderItem> orderItems = new ArrayList<>();
        try {
            setupPreStatement(query);
            for (int i = 0; i < args.length; i++) {
                preStatement.setString(i + 1, args[i]);
            }
            resultSet = preStatement.executeQuery();
            while (resultSet.next()) {
                OrderItem orderItem = OrderItem.builder()
                        .orderId(resultSet.getLong("order_id"))
                        .product(Product.builder()
                                .id(resultSet.getLong("product_id"))
                                .name(resultSet.getString("product_name"))
                                .description(resultSet.getString("description"))
                                .price(resultSet.getDouble("price"))
                                .stockQuantity(resultSet.getInt("stock_quantity"))
                                .category(Category.builder()
                                        .id(resultSet.getLong("category_id"))
                                        .name(resultSet.getString("category_name"))
                                        .isActive(resultSet.getBoolean("c_is_active"))
                                        .build()
                                )
                                .imageUrl(resultSet.getString("image_url"))
                                .isActive(resultSet.getBoolean("is_active"))
                                .build())
                        .quantity(resultSet.getInt("quantity"))
                        .unitPrice(resultSet.getDouble("unit_price"))
                        .build();
                orderItems.add(orderItem);
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return orderItems;
    }

    public List<OrderItem> findAll() {
        String query = IQuery.QUERY_GET_ALL_ORDER_ITEMS;
        return find(query);
    }

    public List<OrderItem> findAllByOrderId(Long orderId) {
        String query = IQuery.QUERY_GET_ALL_ORDER_ITEMS_BY_ORDER_ID;
        return find(query, orderId.toString());
    }

    public OrderItem save(OrderItem orderItem) {
        try {
            setupPreStatement(IQuery.QUERY_INSERT_ORDER_ITEM);
            preStatement.setLong(1, orderItem.getOrderId());
            preStatement.setLong(2, orderItem.getProduct().getId());
            preStatement.setInt(3, orderItem.getQuantity());
            preStatement.setDouble(4, orderItem.getUnitPrice());
            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                return orderItem;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }
}

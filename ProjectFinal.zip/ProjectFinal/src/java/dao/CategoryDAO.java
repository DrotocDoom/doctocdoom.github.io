/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import constant.IQuery;
import entity.Category;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyen
 */
public class CategoryDAO extends ModelDAO {

    public static void main(String[] args) {
        new CategoryDAO().findAll().forEach(c -> System.out.println(c));
    }

    private List<Category> find(String query, String... args) {
        List<Category> categories = new ArrayList<>();
        try {
            setupPreStatement(query);
            for (int i = 0; i < args.length; i++) {
                preStatement.setString(i + 1, args[i]);
            }
            resultSet = preStatement.executeQuery();
            while (resultSet.next()) {
                Category category = Category.builder()
                        .id(resultSet.getLong("category_id"))
                        .name(resultSet.getString("category_name"))
                        .description(resultSet.getString("description"))
                        .isActive(resultSet.getBoolean("is_active"))
                        .build();
                categories.add(category);
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return categories;
    }

    public List<Category> findAll() {
        String query = IQuery.QUERY_GET_ALL_CATEGORIES;
        return find(query);
    }

    public Category findById(Long id) {
        String query = IQuery.QUERY_GET_CATEGORY_BY_ID;
        List<Category> searched = find(query, id.toString());
        return searched.isEmpty() ? null : searched.get(0);
    }

    public Category save(Category category) {
        try {
            boolean insertMode = (category.getId() == null);
            if (!insertMode) {
                setupPreStatement(IQuery.QUERY_UPDATE_CATEGORY);
                preStatement.setLong(4, category.getId());
            } else {
                setupPreStatement(IQuery.QUERY_INSERT_CATEGORY);
            }
            preStatement.setString(1, category.getName());
            preStatement.setString(2, category.getDescription());
            preStatement.setBoolean(3, category.getIsActive());

            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                if (insertMode) {
                    try ( ResultSet generatedKeys = preStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            category.setId(generatedKeys.getLong(1));
                        }
                    }
                }
                return category;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

    public Category delete(Category category) {
        try {
            setupPreStatement(IQuery.QUERY_DELETE_CATEGORY);
            preStatement.setLong(1, category.getId());
            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                return category;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }
}

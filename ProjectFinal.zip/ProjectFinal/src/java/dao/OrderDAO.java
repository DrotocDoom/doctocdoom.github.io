/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import constant.IQuery;
import entity.Customer;
import entity.Order;
import entity.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyen
 */
public class OrderDAO extends ModelDAO {

    public static void main(String[] args) {

        new OrderDAO().findAllByCustomerId(1L).forEach(o -> System.out.println(o));
    }

    private List<Order> find(String query, String... args) {
        List<Order> orders = new ArrayList<>();

        try {
            setupPreStatement(query);
            for (int i = 0; i < args.length; i++) {
                preStatement.setString(i + 1, args[i]);
            }
            resultSet = preStatement.executeQuery();
            while (resultSet.next()) {
                Order order = Order.builder()
                        .id(resultSet.getLong("order_id"))
                        .customer(Customer.builder()
                                .id(resultSet.getLong("customer_id"))
                                .user(User.builder()
                                        .id(resultSet.getLong("user_id"))
                                        .firstName(resultSet.getString("first_name"))
                                        .lastName(resultSet.getString("last_name"))
                                        .email(resultSet.getString("email"))
                                        .isAdmin(resultSet.getBoolean("is_admin"))
                                        .build()
                                )
                                .address(resultSet.getString("address"))
                                .phoneNumber(resultSet.getString("phone_number"))
                                .build())
                        .totalPrice(resultSet.getDouble("total_price"))
                        .orderDate(resultSet.getDate("order_date"))
                        .status(resultSet.getString("status"))
                        .build();
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return orders;
    }

    public List<Order> findAll() {
        String query = IQuery.QUERY_GET_ALL_ORDERS;
        return find(query);
    }

    public Order findById(Long id) {
        String query = IQuery.QUERY_GET_ORDER_BY_ID;
        List<Order> searched = find(query, id.toString());
        Order order = searched.isEmpty() ? null : searched.get(0);
        if (order != null) {
            order.setOrderItems(new OrderItemDAO().findAllByOrderId(id));
        }
        return order;
    }

    public List<Order> findAllByCustomerId(Long id) {
        String query = IQuery.QUERY_GET_ORDER_BY_CUSTOMER_ID;
        return find(query, id + "");
    }

    public List<Order> findStatus(String option) {
        String query = IQuery.QUERY_GET_ORDER_BY_STATUS;
        return find(query, option);
    }

    public List<Order> findStatustop1(String option) {
        String query = IQuery.QUERY_GET_ORDER_BY_STATUS_TOP1;
        return find(query, option);
    }

    public Order save(Order order) {
        try {
            boolean insertMode = (order.getId() == null);
            if (!insertMode) {
                setupPreStatement(IQuery.QUERY_UPDATE_ORDER);
                preStatement.setLong(5, order.getId());
            } else {
                setupPreStatement(IQuery.QUERY_INSERT_ORDER);
            }
            preStatement.setLong(1, order.getCustomer().getId());
            preStatement.setDate(2, new java.sql.Date(order.getOrderDate().getTime()));
            preStatement.setString(3, order.getStatus());

            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                if (insertMode) {
                    try ( ResultSet generatedKeys = preStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            order.setId(generatedKeys.getLong(1));
                        }
                    }
                }
                return order;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

//    public Order delete(Order order) {
//        try {
//            setupPreStatement(IQuery.QUERY_DELETE_ORDER);
//            preStatement.setLong(1, order.getId());
//            int rowsAffected = preStatement.executeUpdate();
//            if (rowsAffected > 0) {
//                return order;
//            }
//        } catch (SQLException e) {
//            System.err.println("Error executing SQL statement");
//            System.err.println(e);
//        } finally {
//            closeResources();
//        }
//        return null;
//    }
}

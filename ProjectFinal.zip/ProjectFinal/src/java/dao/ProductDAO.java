/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import constant.IQuery;
import entity.Category;
import entity.Product;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyen
 */
public class ProductDAO extends ModelDAO {

    public static void main(String[] args) {
        System.out.println(new ProductDAO().findById(1L));
//        new ProductDAO().findAll(2, 2).forEach(c -> System.out.println(c));
    }

    private List<Product> find(String query, Object... args) {
        List<Product> products = new ArrayList<>();
        try {
            setupPreStatement(query);
            for (int i = 0; i < args.length; i++) {
                preStatement.setObject(i + 1, args[i]);
            }
            resultSet = preStatement.executeQuery();
            while (resultSet.next()) {
                Product product = Product.builder()
                        .id(resultSet.getLong("product_id")).
                        name(resultSet.getString("product_name"))
                        .description(resultSet.getString("description"))
                        .price(resultSet.getDouble("price"))
                        .stockQuantity(resultSet.getInt("stock_quantity"))
                        .category(Category.builder()
                                .id(resultSet.getLong("category_id"))
                                .name(resultSet.getString("category_name"))
                                .isActive(resultSet.getBoolean("c_is_active"))
                                .build()
                        )
                        .imageUrl(resultSet.getString("image_url"))
                        .isActive(resultSet.getBoolean("is_active"))
                        .build();
                products.add(product);
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return products;
    }

    public List<Product> findAll() {
        String query = IQuery.QUERY_GET_ALL_PRODUCTS;
        return find(query);
    }

    public int countAll() {
        String query = IQuery.QUERY_COUNT_ALL_PRODUCTS;
        try {
            setupPreStatement(query);
            resultSet = preStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return 0;
    }

    public Product findById(Long id) {
        String query = IQuery.QUERY_GET_PRODUCT_BY_ID;
        List<Product> searched = find(query, id + "");
        return searched.isEmpty() ? null : searched.get(0);
    }

    public List<Product> findByCATEGORYID(Long id) {
        String query = IQuery.QUERY_ALL_PRODUCTS_CATEGORY_ID;
        return find(query, id + "");
    }

    public List<Product> findByNameLike(String name) {
        String query = IQuery.QUERY_GET_PRODUCT_BY_NAME_LIKE;
        return find(query, "%" + name + "%");
    }

    public List<Product> findByNameLike(Integer page, String name) {
        String query = IQuery.QUERY_GET_PAGINATED_PRODUCT_BY_NAME_LIKE;
        int itemsPerPage = 10;
        Integer offset = (page - 1) * itemsPerPage; // Assuming 10 items per page
        return find(query, "%" + name + "%", offset, itemsPerPage);
    }

    public List<Product> findAll(Integer page) {
        return findAll(page, 10);
    }

    public List<Product> findAll(Integer page, Integer itemsPerPage) {
        String query = IQuery.QUERY_GET_PAGINATED_PRODUCTS;
        Integer offset = (page - 1) * itemsPerPage;
        return find(query, offset, itemsPerPage);
    }

    public Product save(Product product) {
        try {
            boolean insertMode = (product.getId() == null);
            if (!insertMode) {
                setupPreStatement(IQuery.QUERY_UPDATE_PRODUCT);
                preStatement.setLong(8, product.getId());
            } else {
                setupPreStatement(IQuery.QUERY_INSERT_PRODUCT);
            }
            preStatement.setString(1, product.getName());
            preStatement.setString(2, product.getDescription());
            preStatement.setDouble(3, product.getPrice());
            preStatement.setInt(4, product.getStockQuantity());
            preStatement.setLong(5, product.getCategory().getId());
            preStatement.setString(6, product.getImageUrl());
            preStatement.setBoolean(7, product.getIsActive());

            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                if (insertMode) {
                    try ( ResultSet generatedKeys = preStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            product.setId(generatedKeys.getLong(1));
                        }
                    }
                }
                return product;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

    public Product delete(Product product) {
        try {
            setupPreStatement(IQuery.QUERY_DELETE_PRODUCT);
            preStatement.setLong(1, product.getId());
            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                return product;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

}

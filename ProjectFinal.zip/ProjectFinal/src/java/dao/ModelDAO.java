/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.DBConnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author nguyen
 */
public class ModelDAO {

    private final DBConnect dbContext;
    private Connection connection;
//    protected Statement statement;
    protected PreparedStatement preStatement;
    protected ResultSet resultSet;

    public ModelDAO() {
        dbContext = new DBConnect();
    }

    public void closeResources() {
        dbContext.closeResources(connection, preStatement, resultSet);
    }

    protected void setupPreStatement(String query) throws SQLException {
        connection = dbContext.getConnection();
        preStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import constant.IQuery;
import entity.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nguyen
 */
public class UserDAO extends ModelDAO {

    public static void main(String[] args) {
        new UserDAO().findAll().forEach(u -> System.out.println(u));
    }

    private List<User> find(String query, String... args) {
        List<User> users = new ArrayList<>();
        try {
            setupPreStatement(query);
            for (int i = 0; i < args.length; i++) {
                preStatement.setString(i + 1, args[i]);
            }
            resultSet = preStatement.executeQuery();
            while (resultSet.next()) {
                User user = User.builder()
                        .id(resultSet.getLong("user_id"))
                        .firstName(resultSet.getString("first_name"))
                        .lastName(resultSet.getString("last_name"))
                        .email(resultSet.getString("email"))
                        .password(resultSet.getString("password"))
                        .isAdmin(resultSet.getBoolean("is_admin"))
                        .build();
                users.add(user);
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return users;
    }

    public List<User> findAll() {
        String query = IQuery.QUERY_GET_ALL_USERS;
        return find(query);
    }

    public User findById(Long id) {
        String query = IQuery.QUERY_GET_USER_BY_ID;
        List<User> searched = find(query, id.toString());
        return searched.isEmpty() ? null : searched.get(0);
    }

    public User findByEmailAndPassword(String email, String password) {
        String query = IQuery.QUERY_GET_USER_BY_EMAIL_AND_PASSWORD;
        List<User> searched = find(query, email, password);
        return searched.isEmpty() ? null : searched.get(0);
    }

    public User findByEmail(String email) {
        String query = IQuery.QUERY_GET_USER_BY_EMAIL;
        List<User> searched = find(query, email);
        return searched.isEmpty() ? null : searched.get(0);
    }

    public User save(User user) {
        try {
            boolean insertMode = (user.getId() == null)
                    || (findById(user.getId()) == null);
            if (!insertMode) {
                setupPreStatement(IQuery.QUERY_UPDATE_USER);
                preStatement.setLong(6, user.getId());
            } else {
                setupPreStatement(IQuery.QUERY_INSERT_USER);
            }
            preStatement.setString(1, user.getEmail());
            preStatement.setString(2, user.getFirstName());
            preStatement.setString(3, user.getLastName());
            preStatement.setString(4, user.getPassword());
            preStatement.setBoolean(5, user.getIsAdmin());
            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                if (insertMode) {
                    try ( ResultSet generatedKeys = preStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            user.setId(generatedKeys.getLong(1));
                        }
                    }
                }
                return user;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

    public User delete(User user) {
        try {
            setupPreStatement(IQuery.QUERY_DELETE_USER);
            preStatement.setLong(1, user.getId());
            int rowsAffected = preStatement.executeUpdate();
            if (rowsAffected > 0) {
                return user;
            }
        } catch (SQLException e) {
            System.err.println("Error executing SQL statement");
            System.err.println(e);
        } finally {
            closeResources();
        }
        return null;
    }

}
